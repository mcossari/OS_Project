#include "console.h"

void main() {

	clear_terminal();
        char* str = "Hello World";

        for (int i = 0; str[i] !='\0'; i++){
                VGA_BUFFER[i*2] = str[i];
        }


	clear_terminal();

	print_string("HELLO");

	print_line("WORLD");

	print_string("TODAY");
	return;
}
